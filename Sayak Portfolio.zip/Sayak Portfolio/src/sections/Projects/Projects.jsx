import styles from './ProjectsStyles.module.css';
import Netflix from '../../assets/Netflix.png';
import Calling from '../../assets/Calling.png';
import FaceMaskDetect from '../../assets/FaceMaskDetect.png';
import Ecommerce from '../../assets/Ecommerce.png';
import ProjectCard from '../../common/ProjectCard';

function Projects() {
  return (
    <section id="projects" className={styles.container}>
      <h1 className="sectionTitle">Projects</h1>
      <div className={styles.projectsContainer}>
        <ProjectCard
          src={Netflix}
          link="https://github.com/SayakPaul22/OctaNet_Task3-Website-Colne"
          h3="Netflix "
          p="Clone of a Streaming app"
        />
        <ProjectCard
          src={Calling}
          link="https://github.com/SayakPaul22/Calling-App"
          h3="Calling App"
          p="Made for voice and video 
           call using JAVA"
        />
        <ProjectCard
          src={FaceMaskDetect}
          link="https://github.com/SayakPaul22/Face-Mask-Detection"
          h3="FaceMask-Detection"
          p="FaceMask detect using AI"
        />
        <ProjectCard
          src={Ecommerce}
          link="https://github.com/SayakPaul22/E-Commerce"
          h3="Ecommerce Website"
          p="Mobile selling website"
        />
      </div>
    </section>
  );
}

export default Projects;
